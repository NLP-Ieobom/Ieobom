# 이어봄 숭실대 AI소프트웨어학부 공개 시연 데이터

2026학년도 입학생 기준 공식 교육과정 52과목과 학년·학기 배치 64건,
2026년 U-SAINT 조회에서 연결한 분반 169건을 담았습니다. 과목당 대표 강의계획서
49건의 주차별 주제는 짧은 색인으로 제공합니다. 조회 범위는 data/offerings.json의
term_status에서 확인할 수 있습니다.

## 사용 방법

1. manifest.json의 course_index에서 과목 목록을 읽습니다.
2. courses 배열에서 course_id를 선택하고 syllabus.path와 syllabus.term을 조회합니다.
   syllabus가 null이면 syllabus_status로 수집 상태를 확인할 수 있습니다.
3. 각 대표 계획서 JSON에서 weekly_topics를 읽습니다.
   week는 1~15이고, topics[0].text는 짧게 정리한 주제입니다.

과목 ID는 개설 분반이나 교육과정 배치를 연결하는 키이며 offering_code는 개설번호입니다.
계획서 색인은 schemas/syllabus.schema.json의 Draft 2020-12 형식을 사용합니다.
주차별 주제와 출처 위치를 제공하는 데이터이므로 과목 개요, 학습 목표, 선수과목은
비워 두었습니다. 이 값은 학교의 공식 판단을 뜻하지 않습니다.
계획서 원문, 상세 설명, 담당자 정보와 강의 PDF는 공개 색인에 포함되지 않습니다.
파일 무결성은 manifest.json의 SHA-256으로 확인할 수 있습니다.

## 출처

- 숭실대학교 AI소프트웨어학부 [2026학년도 입학생 기준 공식 교육과정](https://ai.ssu.ac.kr/api-server/resource/download/327)
- 숭실대학교 [학부 교과과정 안내](https://ai.ssu.ac.kr/guide/curriculum)
- 숭실대학교 [U-SAINT](https://saint.ssu.ac.kr/irj/portal)의 강의시간표 및 계획서
